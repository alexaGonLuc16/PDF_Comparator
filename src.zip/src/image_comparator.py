# image_comparator.py
import numpy as np
from PIL import Image
import cv2

class ImageComparator:
    def __init__(self, threshold=3):
        self.threshold = threshold  # Umbral para diferencias (0-255)
        self.min_contour_area = 5
        self.kernel = np.ones((3, 3), np.uint8)
        
        # Colores para tipos de cambios (B, G, R)
        self.ADDED_COLOR = (255, 0, 0)     # Azul
        self.REMOVED_COLOR = (0, 0, 255)   # Rojo
        self.MODIFIED_COLOR = (0, 255, 0)  # Verde
    
    @staticmethod
    def load_image(image_input):
        # Carga una imagen desde ruta o la convierte si es PIL
        if isinstance(image_input, str):  # Si es una ruta
            img = cv2.imread(image_input)
            if img is None:
                raise ValueError(f"No se pudo cargar la imagen: {image_input}")
            return img
        elif isinstance(image_input, Image.Image):  # Si es PIL (de pdf2image)
            return cv2.cvtColor(np.array(image_input), cv2.COLOR_RGB2BGR)
        else:
            return image_input  # Asume que ya es OpenCV
    
    def find_differences(self, img1_input, img2_input):
        """
        Detecta diferencias en imágenes B/N usando solo OpenCV:
        1. Convierte a escala de grises (si no lo están)
        2. Binariza las imágenes
        3. Encuentra diferencias absolutas
        4. Clasifica los cambios como: agregados, eliminados o modificados
        5. Filtra y resalta cambios con colores según su tipo
        """
        
        img1 = self.load_image(img1_input)  # Imagen original
        img2 = self.load_image(img2_input)  # Imagen nueva
        
        # Asegurar que son imágenes B/N (1 canal)
        if len(img1.shape) > 2:
            img1_gray = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
        else:
            img1_gray = img1.copy()
            
        if len(img2.shape) > 2:
            img2_gray = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
        else:
            img2_gray = img2.copy()
        
        # Binarización (thresholding adaptativo para mayor robustez)
        _, bin1 = cv2.threshold(img1_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        _, bin2 = cv2.threshold(img2_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        # Diferencia absoluta/pixeles que cambian entre ambas imagenes
        diff = cv2.absdiff(bin1, bin2)
        
        # Operaciones morfológicas para mejorar la detección(limpiar ruido)
        diff_processed = cv2.morphologyEx(diff, cv2.MORPH_OPEN, self.kernel)
        diff_processed = cv2.dilate(diff_processed, self.kernel, iterations=1)
        
        # Detectar elementos agregados (blanco en img2, negro en img1)
        added_mask = cv2.bitwise_and(bin2, cv2.bitwise_not(bin1))
        added_mask = cv2.morphologyEx(added_mask, cv2.MORPH_OPEN, self.kernel)
        added_mask = cv2.dilate(added_mask, self.kernel, iterations=1)
        
        # Detectar elementos eliminados (blanco en img1, negro en img2)
        removed_mask = cv2.bitwise_and(bin1, cv2.bitwise_not(bin2))
        removed_mask = cv2.morphologyEx(removed_mask, cv2.MORPH_OPEN, self.kernel)
        removed_mask = cv2.dilate(removed_mask, self.kernel, iterations=1)
        
        # Detectar elementos modificados (diferencia - (agregados + eliminados))
        modified_mask = cv2.bitwise_xor(diff_processed, cv2.bitwise_or(added_mask, removed_mask))
        modified_mask = cv2.morphologyEx(modified_mask, cv2.MORPH_OPEN, self.kernel)
        modified_mask = cv2.dilate(modified_mask, self.kernel, iterations=1)
        
        # Encontrar contornos para cada tipo de cambio
        added_contours, _ = cv2.findContours(added_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        removed_contours, _ = cv2.findContours(removed_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        modified_contours, _ = cv2.findContours(modified_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Filtrar contornos por área mínima
        added_contours = [c for c in added_contours if cv2.contourArea(c) >= self.min_contour_area]
        removed_contours = [c for c in removed_contours if cv2.contourArea(c) >= self.min_contour_area]
        modified_contours = [c for c in modified_contours if cv2.contourArea(c) >= self.min_contour_area]
        
        # Crear listas de coordenadas y tipos de cambios
        diff_coords = []
        diff_coords_type = []
        
        # Agregar las coordenadas de elementos agregados
        for contour in added_contours:
            center = self.get_contour_center(contour)
            radius = self.get_contour_radius(contour)
            if center and radius:
                x, y = center
                print("Cambio detectado(agregado)", x,y, radius)
                diff_coords.append((x, y))
                diff_coords_type.append((x, y, radius, "added"))
        
        # Agregar las coordenadas de elementos eliminados
        for contour in removed_contours:
            center = self.get_contour_center(contour)
            radius = self.get_contour_radius(contour)
            if center and radius:
                x, y = center
                print("Cambio detectado(eliminado)", x,y, radius)
                diff_coords.append((x, y))
                diff_coords_type.append((x, y, radius, "removed"))
        
        # Agregar las coordenadas de elementos modificados
        for contour in modified_contours:
            center = self.get_contour_center(contour)
            radius = self.get_contour_radius(contour)
            if center and radius:
                x, y = center
                print("Cambio detectado(modificado)", x,y, radius)
                diff_coords.append((x, y))
                diff_coords_type.append((x, y, radius, "modified"))
        
        # Resaltar cambios en la imagen original con colores según tipo
        if len(img2.shape) == 2:  # Si la imagen de entrada era B/N, la convertimos a color para el resaltado
            img2_color = cv2.cvtColor(img2, cv2.COLOR_GRAY2BGR)
        else:
            img2_color = img2.copy()
        
        # Dibujar contornos con colores según tipo
        cv2.drawContours(img2_color, added_contours, -1, self.ADDED_COLOR, 2)
        cv2.drawContours(img2_color, removed_contours, -1, self.REMOVED_COLOR, 2)
        cv2.drawContours(img2_color, modified_contours, -1, self.MODIFIED_COLOR, 2)
        
        # Devolver coordenadas de diferencias + imagen resaltada
        return diff_coords, diff_coords_type, img2_color, img1_gray.shape
    
    def get_contour_center(self, contour):
        """Calcula el centro de un contorno basado en su momento."""
        M = cv2.moments(contour)
        if M["m00"] != 0:
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])
            return (cX, cY)
        return None
    
    def get_contour_radius(self, contour):
        """Calcula el radio aproximado de un contorno."""
        area = cv2.contourArea(contour)
        if area > 0:
            # Radio aproximado basado en área de círculo (A = πr²)
            radius = np.sqrt(area / np.pi)
            # Asegurar un radio mínimo para visibilidad
            return max(radius, 5)
        return None