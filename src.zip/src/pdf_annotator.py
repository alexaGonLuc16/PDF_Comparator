# pdf_annotator.py
import fitz  # PyMuPDF
import os
import json

class PDFAnnotator:
    def __init__(self, output_dir='data/output'):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # Definir colores para los diferentes tipos de cambios (R, G, B)
        self.ADDED_COLOR = (0, 0, 1)      # Azul
        self.REMOVED_COLOR = (1, 0, 0)    # Rojo
        self.MODIFIED_COLOR = (0, 1, 0)   # Verde
        self.DEFAULT_COLOR = (1, 0, 0)    # Rojo (por defecto)
    
    def add_circle_annotations(self, input_pdf, circles_by_page, output_pdf=None, dpi=300):
        """
        Añade círculos como anotaciones al PDF con colores según el tipo de cambio.
        
        Args:
            input_pdf: Ruta al PDF original
            circles_by_page: Diccionario {num_página: [(x, y, radio, tipo), ...]}
                             donde tipo puede ser "added", "removed", "modified" o None
            output_pdf: Ruta donde guardar el PDF anotado
            dpi: DPI usados para la conversión a imagen (para escalar coordenadas)
        """
        print("Adding circle annotations")
        print("circle by page",circles_by_page)
        if output_pdf is None:
            base_name = os.path.basename(input_pdf)
            output_pdf = os.path.join(self.output_dir, f"annotated_{base_name}")
        
        # Abrir documento
        doc = fitz.open(input_pdf)
        
        # Factor de escala para convertir de coordenadas de imagen a PDF
        scale_factor = 72 / dpi
        
        # Para cada página con círculos
        for page_num, circles in circles_by_page.items():
            page = doc[int(page_num)]
            
            for circle_data in circles:
                # Extraer datos del círculo
                if len(circle_data) >= 4:
                    x, y, radius, change_type = circle_data
                else:
                    # Compatibilidad con versiones anteriores
                    x, y, radius = circle_data[:3]
                    change_type = None
                
                # Escalar coordenadas
                x_pdf = x * scale_factor
                y_pdf = y * scale_factor
                radius_pdf = radius * scale_factor
                
                # Crear anotación de círculo
                circle = page.add_circle_annot((x_pdf - radius_pdf, y_pdf - radius_pdf,
                                               x_pdf + radius_pdf, y_pdf + radius_pdf))
                
                # Determinar color según el tipo de cambio
                if change_type == "added":
                    color = self.ADDED_COLOR
                elif change_type == "removed":
                    color = self.REMOVED_COLOR
                elif change_type == "modified":
                    color = self.MODIFIED_COLOR
                else:
                    color = self.DEFAULT_COLOR
                
                # Configurar propiedades
                circle.set_border(width=2)
                circle.set_colors(stroke=color)
                circle.update(opacity=0.7)
                
                # Guardar tipo de cambio en los metadatos de la anotación
                info = circle.info
                info["change_type"] = change_type if change_type else "unknown"
                circle.set_info(info)
                
                # Hacer la anotación toggle-able
                circle.set_flags(0)  # No ocultar por defecto
        
                print("Circulo",circle)
        # Guardar documento
        doc.save(output_pdf)
        doc.close()
        
        return output_pdf
            
    def save_circles_to_json(self, circles_by_page, output_path):
        """Guarda la información de los círculos en un archivo JSON."""
        with open(output_path, 'w') as f:
            json.dump(circles_by_page, f, indent=2)